dojo.provide("atg.widget.previewPicker");

dojo.registerModulePath("atg.widget.previewPicker", "/p4/design/PreviewProject/version/acton/sandbox/widgets");

dojo.registerNamespace("previewPicker", "atg.widget.previewPicker");