atg.helpFields=[
  { id: "ea_csc_order_search", type: "inline", helpId: "ea_csc_order_search" },
  { id: "ea_csc_customer_search", type: "inline", helpId: "ea_csc_customer_search" },
  { id: "ea_csc_product_view", type: "inline", helpId: "ea_csc_product_view" },
  { id: "ea_csc_product_item_price", type: "popup", helpId: "ea_csc_product_item_price" }
];
   

