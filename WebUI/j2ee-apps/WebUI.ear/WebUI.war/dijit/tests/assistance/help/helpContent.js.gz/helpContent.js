atg.helpContent={ 
  "helpItem":[
    {
      "id":"ea_csc_order_search",
      "excerpt":"Specify at least one search requirement.",
      "content":"The search button initally appears grayed out and only becomes active once one or more fields are specified."
    },
    {
      "id":"ea_csc_customer_search",
      "excerpt":"Specify at least one search requirement.",
      "content":"The search button initally appears grayed out and only becomes active once one or more fields are specified."
    },
    {
      "id":"ea_csc_product_view",
      "excerpt":"A product has not yet been selected.",
      "content":"To view a product, first select an item from the product catalog or by product ID."
    },
    {
      "id":"ea_csc_product_item_price",
      "content":"Use the operands to identify price ranges. Please use the format 0.00 in the text box to the right of the operand."
    }
  ]
}  
