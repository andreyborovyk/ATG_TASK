if(!dojo._hasResource["dijit.tests.form.Form"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests.form.Form"] = true;
dojo.provide("dijit.tests.form.Form");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.form.Form", dojo.moduleUrl("dijit", "tests/form/Form.html"));
}

}
