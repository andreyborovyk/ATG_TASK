dojo.provide("atg.widget.toggleView");

dojo.registerModulePath("toggleView", "/WebUI/widget/toggleVIew");

dojo.registerNamespace("toggleView", "atg.widget.toggleView");