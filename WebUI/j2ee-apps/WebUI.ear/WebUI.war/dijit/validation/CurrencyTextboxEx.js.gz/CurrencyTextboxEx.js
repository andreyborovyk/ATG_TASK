dojo.provide("atg.widget.validation.CurrencyTextboxEx");
dojo.require("dijit.form.CurrencyTextBox");
dojo.require("dojox.i18n.currency");
dojo.require("dojox.i18n.number");

dojo.declare(
  "atg.widget.validation.CurrencyTextboxEx",
  dijit.form.CurrencyTextBox,
  {

  }
);
