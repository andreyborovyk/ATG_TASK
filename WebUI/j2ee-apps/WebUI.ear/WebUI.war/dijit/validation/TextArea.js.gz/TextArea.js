dojo.provide("atg.widget.validation.TextArea");

dojo.require("dijit.form.ValidationTextBox");

dojo.declare(
  "atg.widget.validation.TextArea",
  dijit.form.TextArea,
  {
  }
);
