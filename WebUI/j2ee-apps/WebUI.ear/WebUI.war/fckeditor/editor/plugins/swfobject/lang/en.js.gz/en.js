FCKLang.DlgFlashvars			= 'Flashvars';

FCKLang.DlgFlashScriptaccess = 'Script Access';
FCKLang.DlgFlashAlways = 'Always';
FCKLang.DlgFlashSameDomain = 'Same Domain';
FCKLang.DlgFlashNever = 'Never';
FCKLang.DlgFlashWindowMode = 'Window Mode';
FCKLang.DlgFlashWindow = 'Window';
FCKLang.DlgFlashOpaque = 'Opaque';
FCKLang.DlgFlashTransparent = 'Transparent';
FCKLang.DlgFlashAllowfullscreen = 'Allow Fullscreen';
