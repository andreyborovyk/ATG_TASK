FCKLang.DlgFlashvars			= 'Flashvars';

FCKLang.DlgFlashScriptaccess = 'Acceso de Scripts';
FCKLang.DlgFlashAlways = 'Siempre';
FCKLang.DlgFlashSameDomain = 'El mismo dominio';
FCKLang.DlgFlashNever = 'Nunca';
FCKLang.DlgFlashWindowMode = 'Wmode';
FCKLang.DlgFlashWindow = 'Ventana';
FCKLang.DlgFlashOpaque = 'Opaco';
FCKLang.DlgFlashTransparent = 'Transparente';
FCKLang.DlgFlashAllowfullscreen = 'Permitir ventana completa';

// para que quede en una linea
FCKLang.DlgFlashChkMenu = 'Menú Flash';
