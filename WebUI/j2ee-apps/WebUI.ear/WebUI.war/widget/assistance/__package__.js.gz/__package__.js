dojo.provide("atg.widget.assistance");
dojo.require("atg.widget.assistance.base");
dojo.require("atg.widget.assistance.inline");
dojo.require("atg.widget.assistance.popup");

dojo.require("dojo.html.*");
dojo.require("dojo.html.iframe");
dojo.registerModulePath("assistance", "/WebUI/widget/assistance");
dojo.registerNamespace("assistance", "atg.widget.assistance");
