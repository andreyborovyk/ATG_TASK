/*
	ToggleView Widget v0.1
	
	- For use with showing hiding blocks of content based on an event or user action.

***************************************************************************/
dojo.provide("ATG.widget.toggleView");

dojo.widget.defineWidget("ATG.widget.toggleView", dojo.widget.DomWidget, {
    
	widgetType: "toggleView",  	
  isContainer: false,
  debugName: 'toggleView',

	triggerEvent: 'click',
	triggerElement: this.domNode,
	triggerTarget: this.domNode,
	


  	
  initialize: function(){


	},
		
	uninitialize: function(){
		
		
	},
	
	
	onToggle: function(){
		
		
	}
	
});


