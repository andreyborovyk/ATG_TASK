({
	fontSize: "Taille",
	fontName: "Police",
	formatBlock: "Mise en forme",

	serif: "serif",
	"sans-serif": "sans serif",
	monospace: "espacement fixe",
	cursive: "cursive",
	fantasy: "fantaisie",

	p: "Paragraphe",
	h1: "En-tête",
	h2: "Sous-en-tête",
	h3: "Sous-sous-en-tête",
	pre: "Pré-mise en forme",

	1: "xxs",
	2: "xs",
	3: "s",
	4: "m",
	5: "l",
	6: "xl",
	7: "xxl"
})