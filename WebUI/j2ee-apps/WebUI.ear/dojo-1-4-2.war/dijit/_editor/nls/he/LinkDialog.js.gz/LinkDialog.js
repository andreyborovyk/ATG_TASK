({
	createLinkTitle: "תכונות קישור",
	insertImageTitle: "תכונות תמונה",
	url: "URL:‏",
	text: "תיאור:",
	set: "הגדרה"
})
