({
	createLinkTitle: "Linkeigenschappen",
	insertImageTitle: "Afbeeldingseigenschappen",
	url: "URL:",
	text: "Beschrijving:",
	set: "Instellen"
})
