({
	fontSize: "大小",
	fontName: "字型",
	formatBlock: "格式",

	serif: "新細明體",
	"sans-serif": "新細明體",
	monospace: "等寬",
	cursive: "Cursive",
	fantasy: "Fantasy",

	p: "段落",
	h1: "標題",
	h2: "子標題",
	h3: "次子標題",
	pre: "預先格式化",

	1: "最小",
	2: "較小",
	3: "小",
	4: "中",
	5: "大",
	6: "較大",
	7: "最大"
})