({
		previousMessage: "Opciones anteriores",
		nextMessage: "Más opciones"
})
