({
		previousMessage: "Föregående alternativ",
		nextMessage: "Fler alternativ"
})
