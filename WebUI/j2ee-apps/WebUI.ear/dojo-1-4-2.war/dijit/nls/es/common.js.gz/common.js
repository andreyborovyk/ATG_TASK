({
	buttonOk: "Aceptar",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Cerrar"
})
