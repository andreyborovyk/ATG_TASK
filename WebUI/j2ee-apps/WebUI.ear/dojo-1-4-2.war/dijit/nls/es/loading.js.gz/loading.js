({
	loadingState: "Cargando...",
	errorState: "Lo siento, se ha producido un error"
})
