({
	loadingState: "Läser in...",
	errorState: "Det uppstod ett fel."
})
