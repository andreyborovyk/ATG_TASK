/*=====
// dijit fallback for key summaries otherwise not covered by the doc parser

dijit.demos = {
	// summary:
	//		Home of the official dijit demo code
};

dijit.form = {
	// summary:
	//		Form and input related widgets
};

dijit.layout = {
	// summary:
	//		Layout related widgets
};
=====*/
