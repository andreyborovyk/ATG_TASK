// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Dolar australský",
	CAD_displayName:"Dolar kanadský",
	CHF_displayName:"Frank švýcarský",
	CNY_displayName:"Juan renminbi",
	EUR_displayName:"Euro",
	GBP_displayName:"Libra šterlinků",
	HKD_displayName:"Dolar hongkongský",
	JPY_displayName:"Jen",
	USD_displayName:"Dolar americký"
})
                 