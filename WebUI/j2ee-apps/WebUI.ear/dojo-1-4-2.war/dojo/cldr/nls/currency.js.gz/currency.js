// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_symbol:"AU$",
	CAD_symbol:"CA$",
	CHF_symbol:"Fr.",
	CNY_symbol:"CN¥",
	EUR_symbol:"€",
	GBP_symbol:"£",
	HKD_symbol:"HK$",
	JPY_symbol:"JP¥",
	USD_symbol:"US$"
})
                 