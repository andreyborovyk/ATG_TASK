// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_symbol:"$",
	USD_symbol:"US$"
})
                 