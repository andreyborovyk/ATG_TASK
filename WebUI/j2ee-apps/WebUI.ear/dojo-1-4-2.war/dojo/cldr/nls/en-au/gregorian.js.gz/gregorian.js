// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
	'dateFormat-full': "EEEE, d MMMM y",
	'dateFormat-long': "d MMMM y",
	'dateFormat-medium': "dd/MM/yyyy",
	'dateFormat-short': "d/MM/yy",
	'dateFormatItem-MMdd':"dd/MM",
	'dateFormatItem-MMMMd':"d MMMM",
	'dateFormatItem-yyyyMM':"MM/yyyy",
	'dateFormatItem-yyyyMMMM':"MMMM y"
})
                        