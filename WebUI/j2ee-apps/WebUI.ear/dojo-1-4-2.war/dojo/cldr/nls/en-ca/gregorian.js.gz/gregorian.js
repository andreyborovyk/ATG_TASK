// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
	'dateFormat-medium': "yyyy-MM-dd",
	'dateFormat-short': "yy-MM-dd",
	'dateFormatItem-MMdd':"MM-dd",
	'dateFormatItem-yyMMM':"MMM-yy"
})
                        