// generated from ldml/main/*.xml, xpath: ldml/numbers
({
	'currencyFormat':"¤#,##0.00"
})
