// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"dólar australiano",
	CAD_displayName:"dólar canadiense",
	CHF_displayName:"franco suizo",
	CNY_displayName:"yuan renminbi chino",
	EUR_displayName:"euro",
	GBP_displayName:"libra esterlina británica",
	HKD_displayName:"dólar de Hong Kong",
	JPY_displayName:"yen japonés",
	USD_displayName:"dólar estadounidense"
})
                 