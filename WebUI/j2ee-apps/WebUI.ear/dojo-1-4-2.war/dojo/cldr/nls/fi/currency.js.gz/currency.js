// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Australian dollari",
	AUD_symbol:"AUD",
	CAD_displayName:"Kanadan dollari",
	CAD_symbol:"CAD",
	CHF_displayName:"Sveitsin frangi",
	CHF_symbol:"CHF",
	CNY_displayName:"Kiinan yuan",
	CNY_symbol:"CNY",
	EUR_displayName:"euro",
	GBP_displayName:"Englannin punta",
	HKD_displayName:"Hongkongin dollari",
	HKD_symbol:"HKD",
	JPY_displayName:"Japanin jeni",
	JPY_symbol:"¥",
	USD_displayName:"Yhdysvaltain dollari",
	USD_symbol:"$"
})
                 