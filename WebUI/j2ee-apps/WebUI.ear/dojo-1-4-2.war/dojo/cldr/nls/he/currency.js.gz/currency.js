// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"דולר אוסטרלי",
	CAD_displayName:"דולר קנדי",
	CHF_displayName:"פרנק שוויצרי",
	CNY_displayName:"יואן רנמינבי סיני",
	EUR_displayName:"אירו",
	GBP_displayName:"לירה שטרלינג",
	HKD_displayName:"דולר הונג קונגי",
	JPY_displayName:"ין יפני",
	USD_displayName:"דולר אמריקאי"
})
                 