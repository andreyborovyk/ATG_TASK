// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Dollaro Australiano",
	CAD_displayName:"Dollaro Canadese",
	CHF_displayName:"Franco Svizzero",
	CNY_displayName:"Renmimbi Cinese",
	EUR_displayName:"Euro",
	GBP_displayName:"Sterlina Inglese",
	HKD_displayName:"Dollaro di Hong Kong",
	JPY_displayName:"Yen Giapponese",
	USD_displayName:"Dollaro Statunitense"
})
                 