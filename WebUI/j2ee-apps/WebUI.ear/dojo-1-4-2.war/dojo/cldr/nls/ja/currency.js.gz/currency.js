// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"オーストラリア ドル",
	CAD_displayName:"カナダ ドル",
	CHF_displayName:"スイス フラン",
	CNY_displayName:"中国人民元",
	CNY_symbol:"元",
	EUR_displayName:"ユーロ",
	GBP_displayName:"英国ポンド",
	HKD_displayName:"香港ドル",
	JPY_displayName:"日本円",
	JPY_symbol:"￥",
	USD_displayName:"米ドル",
	USD_symbol:"$"
})
                 