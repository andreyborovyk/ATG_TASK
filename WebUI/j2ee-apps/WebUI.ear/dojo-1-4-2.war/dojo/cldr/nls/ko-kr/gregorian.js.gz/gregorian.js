// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
        'timeFormat-medium': "a h:mm:ss",
        'timeFormat-short': "a h:mm"
})
                        