// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"australske dollar",
	AUD_symbol:"AUD",
	CAD_displayName:"kanadiske dollar",
	CAD_symbol:"CAD",
	CHF_displayName:"sveitsiske franc",
	CHF_symbol:"CHF",
	CNY_displayName:"kinesiske yuan renminbi",
	CNY_symbol:"CNY",
	EUR_displayName:"euro",
	EUR_symbol:"EUR",
	GBP_displayName:"britiske pund sterling",
	GBP_symbol:"GBP",
	HKD_displayName:"Hongkong-dollar",
	JPY_displayName:"japanske yen",
	JPY_symbol:"JPY",
	USD_displayName:"amerikanske dollar",
	USD_symbol:"USD"
})
                 