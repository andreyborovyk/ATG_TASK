// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"dolar australijski",
	CAD_displayName:"dolar kanadyjski",
	CHF_displayName:"frank szwajcarski",
	CNY_displayName:"juan renminbi",
	EUR_displayName:"euro",
	GBP_displayName:"funt szterling",
	HKD_displayName:"dolar hongkoński",
	JPY_displayName:"jen japoński",
	USD_displayName:"dolar amerykański "
})
                 