({
	"dateFormatItem-yyQ": "QQQ 'de' yy", 
	"quarters-standAlone-wide": [
		"1.º trimestre", 
		"2.º trimestre", 
		"3.º trimestre", 
		"4.º trimestre"
	], 
	"months-standAlone-abbr": [
		"Jan", 
		"Fev", 
		"Mar", 
		"Abr", 
		"Mai", 
		"Jun", 
		"Jul", 
		"Ago", 
		"Set", 
		"Out", 
		"Nov", 
		"Dez"
	], 
	"quarters-format-abbr": [
		"1.º trimestre", 
		"2.º trimestre", 
		"3.º trimestre", 
		"4.º trimestre"
	], 
	"dateFormat-medium": "d 'de' MMM 'de' yyyy", 
	"am": "Antes do meio-dia", 
	"months-format-abbr": [
		"Jan", 
		"Fev", 
		"Mar", 
		"Abr", 
		"Mai", 
		"Jun", 
		"Jul", 
		"Ago", 
		"Set", 
		"Out", 
		"Nov", 
		"Dez"
	], 
	"dateFormatItem-yQ": "QQQ 'de' yyyy", 
	"quarters-format-wide": [
		"1.º trimestre", 
		"2.º trimestre", 
		"3.º trimestre", 
		"4.º trimestre"
	], 
	"pm": "Depois do meio-dia", 
	"dateFormatItem-yQQQ": "QQQ 'de' y", 
	"months-standAlone-wide": [
		"Janeiro", 
		"Fevereiro", 
		"Março", 
		"Abril", 
		"Maio", 
		"Junho", 
		"Julho", 
		"Agosto", 
		"Setembro", 
		"Outubro", 
		"Novembro", 
		"Dezembro"
	], 
	"quarters-standAlone-abbr": [
		"1.º trimestre", 
		"2.º trimestre", 
		"3.º trimestre", 
		"4.º trimestre"
	], 
	"months-format-wide": [
		"Janeiro", 
		"Fevereiro", 
		"Março", 
		"Abril", 
		"Maio", 
		"Junho", 
		"Julho", 
		"Agosto", 
		"Setembro", 
		"Outubro", 
		"Novembro", 
		"Dezembro"
	]
})