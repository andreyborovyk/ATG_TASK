// generated from ldml/main/*.xml, xpath: ldml/numbers
({
	'group':" ",
	'currencyFormat':"#,##0.00 ¤"
})
