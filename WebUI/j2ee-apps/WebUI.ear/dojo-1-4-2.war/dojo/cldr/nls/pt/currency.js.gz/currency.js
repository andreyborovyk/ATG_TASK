// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Dólar australiano",
	CAD_displayName:"Dólar canadense",
	CHF_displayName:"Franco suíço",
	CNY_displayName:"Yuan Renminbi chinês",
	EUR_displayName:"Euro",
	GBP_displayName:"Libra esterlina britânica",
	HKD_displayName:"Dólar de Hong Kong",
	JPY_displayName:"Iene japonês",
	USD_displayName:"Dólar norte-americano"
})
                 