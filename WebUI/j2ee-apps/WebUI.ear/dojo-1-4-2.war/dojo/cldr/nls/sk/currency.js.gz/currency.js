// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Austrálsky dolár",
	CAD_displayName:"Kanadský dolár",
	CHF_displayName:"Švajčiarský frank",
	CNY_displayName:"Čínsky Yuan Renminbi",
	EUR_displayName:"Euro",
	GBP_displayName:"Britská libra",
	HKD_displayName:"Hong Kongský dolár",
	JPY_displayName:"Japonský yen",
	USD_displayName:"US dolár"
})
                 