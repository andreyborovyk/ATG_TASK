// generated from ldml/main/*.xml, xpath: ldml/numbers
({
	'decimal':",",
	'group':" ",
	'currencyFormat':"#,##0.00 ¤"
})
