// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"australisk dollar",
	CAD_displayName:"kanadensisk dollar",
	CAD_symbol:"CAD",
	CHF_displayName:"schweizisk franc",
	CHF_symbol:"CHF",
	CNY_displayName:"kinesisk yuan renminbi",
	CNY_symbol:"CNY",
	EUR_displayName:"euro",
	GBP_displayName:"brittiskt pund sterling",
	HKD_displayName:"Hongkong-dollar",
	JPY_displayName:"japansk yen",
	USD_displayName:"US-dollar"
})
                 