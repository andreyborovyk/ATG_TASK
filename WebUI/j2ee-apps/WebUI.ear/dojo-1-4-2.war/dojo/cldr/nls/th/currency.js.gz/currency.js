// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"ดอลลาร์ออสเตรเลีย",
	CAD_displayName:"ดอลลาร์แคนาดา",
	CHF_displayName:"ฟรังก์สวิส",
	CNY_displayName:"หยวนเหรินหมินปี้ (สาธารณรัฐประชาชนจีน)",
	EUR_displayName:"ยูโร",
	GBP_displayName:"ปอนด์สเตอร์ลิง (สหราชอาณาจักร)",
	HKD_displayName:"ดอลลาร์ฮ่องกง",
	JPY_displayName:"เยนญี่ปุ่น",
	JPY_symbol:"¥",
	USD_displayName:"ดอลลาร์สหรัฐ"
})
                 