// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Avustralya Doları",
	CAD_displayName:"Kanada Doları",
	CHF_displayName:"İsviçre Frangı",
	CNY_displayName:"Çin Yuanı Renminbi",
	EUR_displayName:"Euro",
	GBP_displayName:"İngiliz Sterlini",
	HKD_displayName:"Hong Kong Doları",
	JPY_displayName:"Japon Yeni",
	JPY_symbol:"¥",
	USD_displayName:"ABD Doları",
	USD_symbol:"$"
})
                 