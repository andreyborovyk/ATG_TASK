// generated from ldml/main/*.xml, xpath: ldml/calendars/calendar-gregorian
({
        'dateFormat-full': "yyyy'年'M'月'd'日'EEEE",
        'dateFormat-long': "yyyy'年'M'月'd'日'",
        'dateFormat-medium': "yyyy-M-d",
        'dateFormat-short': "yy-M-d",
        'timeFormat-full': "ahh'时'mm'分'ss'秒' z",
        'timeFormat-long': "ahh'时'mm'分'ss'秒'",
        'timeFormat-medium': "ahh:mm:ss",
        'timeFormat-short': "ah:mm"
})
                        