// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"澳大利亚元",
	CAD_displayName:"加拿大元",
	CHF_displayName:"瑞士法郎",
	CNY_displayName:"人民币",
	CNY_symbol:"￥",
	EUR_displayName:"欧元",
	GBP_displayName:"英镑",
	HKD_displayName:"港元",
	JPY_displayName:"日元",
	USD_displayName:"美元"
})
                 