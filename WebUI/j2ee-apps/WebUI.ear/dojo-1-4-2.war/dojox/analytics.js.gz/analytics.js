dojo.provide("dojox.analytics");
dojo.require("dojox.analytics._base");

