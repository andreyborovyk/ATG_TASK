({
	doNew: "[new]",
	edit: "[edit]",
	save: "[save]",
	cancel: "[cancel]"
})