({
	displayOptions: "[display options]",
	title: "Title",
	authors: "Authors",
	contributors: "Contributors",
	id: "ID",
	close: "[close]",
	updated: "Updated",
	summary: "Summary",
	content: "Content"
})