({
	deleteButton: "[Delete]"
})