({
	add: "Add",
	addAuthor: "Add Author",
	addContributor: "Add Contributor"
})