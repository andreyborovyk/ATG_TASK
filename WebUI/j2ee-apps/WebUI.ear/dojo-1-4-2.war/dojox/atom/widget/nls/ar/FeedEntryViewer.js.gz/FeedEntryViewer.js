({
	displayOptions: "[اختيارات العرض]",
	title: "العنوان",
	authors: "المؤلفين",
	contributors: "المساهمين",
	id: "الكود",
	close: "[اغلاق]",
	updated: "تعديل في",
	summary: "الملخص",
	content: "محتويات"
})
