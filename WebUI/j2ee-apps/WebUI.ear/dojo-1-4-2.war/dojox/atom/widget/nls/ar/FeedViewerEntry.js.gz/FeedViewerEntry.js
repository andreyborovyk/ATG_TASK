({
	deleteButton: "[حذف]"
})
