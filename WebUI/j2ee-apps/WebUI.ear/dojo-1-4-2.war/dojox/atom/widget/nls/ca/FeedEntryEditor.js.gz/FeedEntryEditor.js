({
	doNew: "[nou]",
	edit: "[edita]",
	save: "[desa]",
	cancel: "[cancel·la]"
})

