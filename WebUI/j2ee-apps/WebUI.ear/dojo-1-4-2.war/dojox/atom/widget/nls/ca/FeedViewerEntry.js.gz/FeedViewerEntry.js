({
	deleteButton: "[Suprimeix]"
})

