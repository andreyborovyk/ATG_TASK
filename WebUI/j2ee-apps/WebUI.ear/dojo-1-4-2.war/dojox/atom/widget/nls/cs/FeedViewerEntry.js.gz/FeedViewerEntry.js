({
	deleteButton: "[Odstranit]"
})