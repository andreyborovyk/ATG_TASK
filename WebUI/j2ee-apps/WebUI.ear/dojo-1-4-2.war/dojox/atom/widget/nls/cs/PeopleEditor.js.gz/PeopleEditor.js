({
	add: "Přidat",
	addAuthor: "Přidat autora",
	addContributor: "Přidat přispěvatele"
})