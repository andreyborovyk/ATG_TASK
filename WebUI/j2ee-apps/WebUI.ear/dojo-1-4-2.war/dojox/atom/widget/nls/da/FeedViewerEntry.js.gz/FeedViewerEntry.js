({
	deleteButton: "[Slet]"
})
