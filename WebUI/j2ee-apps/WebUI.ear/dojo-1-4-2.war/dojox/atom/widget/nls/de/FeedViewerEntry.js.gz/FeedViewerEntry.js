({
	deleteButton: "[Löschen]"
})