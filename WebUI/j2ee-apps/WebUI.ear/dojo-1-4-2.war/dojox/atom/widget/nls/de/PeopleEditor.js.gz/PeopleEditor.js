({
	add: "Hinzufügen",
	addAuthor: "Autor hinzufügen",
	addContributor: "Mitwirkenden hinzufügen"
})