({
	deleteButton: "[Διαγραφή]"
})
