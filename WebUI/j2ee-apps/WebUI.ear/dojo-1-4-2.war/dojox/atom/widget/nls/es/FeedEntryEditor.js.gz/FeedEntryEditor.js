({
	doNew: "[nuevo]",
	edit: "[editar]",
	save: "[guardar]",
	cancel: "[cancelar]"
})