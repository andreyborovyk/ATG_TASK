({
	displayOptions: "[opciones de visualización]",
	title: "Título",
	authors: "Autores",
	contributors: "Colaboradores",
	id: "ID",
	close: "[cerrar]",
	updated: "Actualizado",
	summary: "Resumen",
	content: "Contenido"
})