({
	deleteButton: "[Suprimir]"
})