({
	add: "Añadir",
	addAuthor: "Añadir autor",
	addContributor: "Añadir colaborador"
})