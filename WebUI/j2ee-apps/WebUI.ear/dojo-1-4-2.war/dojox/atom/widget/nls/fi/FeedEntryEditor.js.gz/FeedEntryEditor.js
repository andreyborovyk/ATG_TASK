({
	doNew: "[uusi]",
	edit: "[muokkaa]",
	save: "[tallenna]",
	cancel: "[peruuta]"
})
