({
	displayOptions: "[näyttöasetukset]",
	title: "Otsikko",
	authors: "Tekijät",
	contributors: "Osallistujat",
	id: "Tunnus",
	close: "[sulje]",
	updated: "Päivitetty",
	summary: "Yhteenveto",
	content: "Sisältö"
})
