({
	deleteButton: "[Poista]"
})
