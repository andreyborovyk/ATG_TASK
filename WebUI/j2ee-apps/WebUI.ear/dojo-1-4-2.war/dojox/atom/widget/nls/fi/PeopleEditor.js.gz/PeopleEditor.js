({
	add: "Lisää",
	addAuthor: "Lisää tekijä",
	addContributor: "Lisää osallistuja"
})
