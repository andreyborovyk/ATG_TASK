({
	doNew: "[nouveau]",
	edit: "[éditer]",
	save: "[sauvegarder]",
	cancel: "[annuler]"
})