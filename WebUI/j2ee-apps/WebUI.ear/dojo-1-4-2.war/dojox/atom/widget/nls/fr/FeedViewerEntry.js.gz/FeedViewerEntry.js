({
	deleteButton: "[Supprimer]"
})