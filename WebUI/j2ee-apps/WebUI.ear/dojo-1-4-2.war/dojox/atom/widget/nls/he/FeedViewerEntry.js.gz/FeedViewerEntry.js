({
	deleteButton: "[מחיקה]"
})
