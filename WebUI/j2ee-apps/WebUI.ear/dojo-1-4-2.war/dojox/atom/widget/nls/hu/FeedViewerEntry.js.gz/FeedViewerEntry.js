({
	deleteButton: "[Törlés]"
})