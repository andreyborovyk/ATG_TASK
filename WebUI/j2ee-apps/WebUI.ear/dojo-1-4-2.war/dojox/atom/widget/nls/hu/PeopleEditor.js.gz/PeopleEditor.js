({
	add: "Hozzáadás",
	addAuthor: "Szerző hozzáadása",
	addContributor: "Közreműködő hozzáadása"
})