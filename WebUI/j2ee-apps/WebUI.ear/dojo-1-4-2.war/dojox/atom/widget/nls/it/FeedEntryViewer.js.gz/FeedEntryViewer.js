({
	displayOptions: "[visualizza opzioni]",
	title: "Titolo",
	authors: "Autori",
	contributors: "Collaboratori",
	id: "ID",
	close: "[chiudi]",
	updated: "Aggiornato",
	summary: "Riepilogo",
	content: "Indice"
})