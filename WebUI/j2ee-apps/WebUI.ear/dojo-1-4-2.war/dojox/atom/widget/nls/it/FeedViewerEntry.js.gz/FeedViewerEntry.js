({
	deleteButton: "[Cancella]"
})