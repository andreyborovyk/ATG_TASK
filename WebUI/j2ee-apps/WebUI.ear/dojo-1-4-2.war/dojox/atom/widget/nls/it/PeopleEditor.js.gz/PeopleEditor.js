({
	add: "Aggiungi",
	addAuthor: "Aggiungi autore",
	addContributor: "Aggiungi collaboratori"
})