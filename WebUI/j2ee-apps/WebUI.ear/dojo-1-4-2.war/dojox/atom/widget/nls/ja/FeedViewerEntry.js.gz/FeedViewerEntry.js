({
	deleteButton: "[削除]"
})