({
	displayOptions: "[옵션 표시]",
	title: "제목",
	authors: "작성자",
	contributors: "속성",
	id: "ID",
	close: "[닫기]",
	updated: "갱신",
	summary: "요약",
	content: "컨텐츠"
})