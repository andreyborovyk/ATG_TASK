({
	deleteButton: "[삭제]"
})