({
	deleteButton: "[Slett]"
})
