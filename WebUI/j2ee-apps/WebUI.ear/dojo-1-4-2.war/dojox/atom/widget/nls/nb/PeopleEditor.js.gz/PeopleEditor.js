({
	add: "Legg til",
	addAuthor: "Legg til forfatter",
	addContributor: "Legg til bidragsyter"
})
