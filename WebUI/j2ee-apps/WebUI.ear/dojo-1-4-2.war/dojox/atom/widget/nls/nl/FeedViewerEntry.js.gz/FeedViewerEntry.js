({
	deleteButton: "[Wissen]"
})
