({
	add: "Toevoegen",
	addAuthor: "Auteur toevoegen",
	addContributor: "Deelnemer toevoegen"
})
