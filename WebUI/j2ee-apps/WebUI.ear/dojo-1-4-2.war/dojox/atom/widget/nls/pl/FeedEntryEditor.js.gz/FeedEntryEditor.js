({
	doNew: "[Nowy]",
	edit: "[Edytuj]",
	save: "[Zapisz]",
	cancel: "[Anuluj]"
})