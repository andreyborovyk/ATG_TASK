({
	displayOptions: "[Opcje wyświetlania]",
	title: "Tytuł",
	authors: "Autorzy",
	contributors: "Kontrybutorzy",
	id: "Identyfikator",
	close: "[Zamknij]",
	updated: "Zaktualizowano",
	summary: "Podsumowanie",
	content: "Treść"
})