({
	deleteButton: "[Usuń]"
})