({
	deleteButton: "[Eliminar]"
})
