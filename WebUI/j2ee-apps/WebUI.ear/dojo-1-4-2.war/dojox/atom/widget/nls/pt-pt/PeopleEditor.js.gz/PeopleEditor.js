({
	add: "Adicionar",
	addAuthor: "Adicionar autor",
	addContributor: "Adicionar contribuinte"
})
