({
	doNew: "[novo]",
	edit: "[editar]",
	save: "[salvar]",
	cancel: "[cancelar]"
})