({
	deleteButton: "[Excluir]"
})