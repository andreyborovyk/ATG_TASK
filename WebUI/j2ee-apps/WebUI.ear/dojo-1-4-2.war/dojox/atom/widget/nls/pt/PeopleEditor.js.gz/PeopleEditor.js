({
	add: "Adicionar",
	addAuthor: "Adicionar Autor",
	addContributor: "Adicionar Contribuidor"
})