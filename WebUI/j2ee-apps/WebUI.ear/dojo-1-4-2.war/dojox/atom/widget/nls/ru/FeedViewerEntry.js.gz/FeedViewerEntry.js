({
	deleteButton: "[Удалить]"
})