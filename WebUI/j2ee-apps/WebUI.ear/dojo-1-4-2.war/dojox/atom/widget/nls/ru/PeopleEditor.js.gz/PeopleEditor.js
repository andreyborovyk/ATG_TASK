({
	add: "Добавить",
	addAuthor: "Добавить автора",
	addContributor: "Добавить участника"
})