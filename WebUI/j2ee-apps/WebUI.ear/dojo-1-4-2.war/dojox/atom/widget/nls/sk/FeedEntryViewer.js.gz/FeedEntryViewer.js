({
	displayOptions: "[zobraziť voľby]",
	title: "Nadpis",
	authors: "Autori",
	contributors: "Prispievatelia",
	id: "ID",
	close: "[zatvoriť]",
	updated: "Aktualizovaný",
	summary: "Súhrn",
	content: "Obsah"
})

