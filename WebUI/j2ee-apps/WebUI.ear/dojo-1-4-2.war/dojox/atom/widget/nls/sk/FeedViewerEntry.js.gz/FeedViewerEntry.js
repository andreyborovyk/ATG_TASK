({
	deleteButton: "[Vymazať]"
})

