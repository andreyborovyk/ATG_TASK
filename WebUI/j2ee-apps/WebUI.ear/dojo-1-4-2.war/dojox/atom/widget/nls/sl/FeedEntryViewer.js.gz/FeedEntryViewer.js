({
	displayOptions: "[možnosti prikaza]",
	title: "Naslov",
	authors: "Avtorji",
	contributors: "Kontributorji",
	id: "ID",
	close: "[zapri]",
	updated: "Posodobljeno",
	summary: "Povzetek",
	content: "Vsebina"
})

