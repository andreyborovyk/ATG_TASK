({
	deleteButton: "[Izbriši]"
})

