({
	add: "Dodaj",
	addAuthor: "Dodaj avtorja",
	addContributor: "Dodaj kontributorja,"
})

