({
	doNew: "[Nytt]",
	edit: "[Redigera]",
	save: "[Spara]",
	cancel: "[Avbryt]"
})
