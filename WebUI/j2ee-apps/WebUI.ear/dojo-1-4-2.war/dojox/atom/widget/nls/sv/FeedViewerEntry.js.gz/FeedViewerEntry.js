({
	deleteButton: "[Ta bort]"
})
