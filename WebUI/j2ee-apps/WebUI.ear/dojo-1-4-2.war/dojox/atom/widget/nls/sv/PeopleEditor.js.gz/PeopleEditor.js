({
	add: "Lägg til ",
	addAuthor: "Lägg till författare",
	addContributor: "Lägg till medverkande"
})
