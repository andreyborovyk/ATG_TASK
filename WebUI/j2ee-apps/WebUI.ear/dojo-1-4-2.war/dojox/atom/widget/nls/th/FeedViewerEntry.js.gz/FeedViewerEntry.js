({
	deleteButton: "[ลบ]"
})

