({
	add: "เพิ่ม",
	addAuthor: "เพิ่มผู้เขียน",
	addContributor: "เพิ่มผู้อนุเคราะห์"
})

