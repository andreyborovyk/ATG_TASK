({
	deleteButton: "[Sil]"
})
