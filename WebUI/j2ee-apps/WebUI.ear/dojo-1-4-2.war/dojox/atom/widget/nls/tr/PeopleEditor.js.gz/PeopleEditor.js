({
	add: "Ekle",
	addAuthor: "Yazar Ekle",
	addContributor: "Katkıda Bulunan Ekle"
})
