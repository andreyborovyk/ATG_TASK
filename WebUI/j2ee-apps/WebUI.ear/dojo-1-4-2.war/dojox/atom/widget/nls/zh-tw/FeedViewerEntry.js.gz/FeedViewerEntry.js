({
	deleteButton: "[刪除]"
})