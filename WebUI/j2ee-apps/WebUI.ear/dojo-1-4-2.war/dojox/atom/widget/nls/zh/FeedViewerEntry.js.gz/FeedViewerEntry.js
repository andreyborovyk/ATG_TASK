({
	deleteButton: "[删除]"
})