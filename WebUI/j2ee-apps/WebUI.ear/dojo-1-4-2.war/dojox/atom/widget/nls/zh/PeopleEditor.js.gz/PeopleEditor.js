({
	add: "添加",
	addAuthor: "添加作者",
	addContributor: "添加内容添加者"
})