dojo.provide("dojox.charting.themes.Algae");
dojo.require("dojox.charting.Theme");

(function(){
	var dxc=dojox.charting;
	dxc.themes.Algae=new dxc.Theme({
		colors: [
			"#57808f",
			"#506885",
			"#4f7878",
			"#558f7f",
			"#508567"
		]
	});
})();
