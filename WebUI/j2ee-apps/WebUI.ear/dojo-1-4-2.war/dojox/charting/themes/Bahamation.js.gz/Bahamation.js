dojo.provide("dojox.charting.themes.Bahamation");
dojo.require("dojox.charting.Theme");

(function(){
	var dxc=dojox.charting;
	dxc.themes.Bahamation=new dxc.Theme({
		colors: [
			"#3f9998",
			"#3fc0c3",
			"#70c058",
			"#ef446f",
			"#c663a6"
		]
	});
})();
