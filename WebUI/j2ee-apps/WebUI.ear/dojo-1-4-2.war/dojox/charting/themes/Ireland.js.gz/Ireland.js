dojo.provide("dojox.charting.themes.Ireland");
dojo.require("dojox.charting.Theme");

(function(){
	var dxc=dojox.charting;
	dxc.themes.Ireland=new dxc.Theme({
		colors: [
			"#abdbcb", 
			"#435a51",
			"#70998b",
			"#78q596",
			"#5f8074"
		]
	});
})();
