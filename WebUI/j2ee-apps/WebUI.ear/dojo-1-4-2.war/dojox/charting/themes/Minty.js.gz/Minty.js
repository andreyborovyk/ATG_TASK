dojo.provide("dojox.charting.themes.Minty");
dojo.require("dojox.charting.Theme");

(function(){
	var dxc=dojox.charting;
	dxc.themes.Minty=new dxc.Theme({
		colors: [
			"#80ccbb", 
			"#539e8b",
			"#335f54",
			"#8dd1c2",
			"#68c5ad"
		]
	});
})();
