dojo.provide("dojox.color");
dojo.require("dojox.color._base");
