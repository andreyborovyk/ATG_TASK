dojo.provide("dojox.cometd.longPollTransport");
dojo.require("dojox.cometd.longPollTransportJsonEncoded");
