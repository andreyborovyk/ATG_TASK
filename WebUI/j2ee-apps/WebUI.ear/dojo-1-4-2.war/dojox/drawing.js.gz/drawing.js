dojo.provide("dojox.drawing");
dojo.require("dojox.drawing._base");