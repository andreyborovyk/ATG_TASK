dojo.provide("dojox.dtl");
dojo.require("dojox.dtl._base");