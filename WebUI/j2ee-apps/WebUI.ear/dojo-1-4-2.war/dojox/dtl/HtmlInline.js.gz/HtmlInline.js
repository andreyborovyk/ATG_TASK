dojo.provide("dojox.dtl.HtmlInline");
dojo.require("dojox.dtl.DomInline");
dojo.deprecated("dojox.dtl.html", "All packages and classes in dojox.dtl that start with Html or html have been renamed to Dom or dom");
dojox.dtl.HtmlInline = dojox.dtl.DomInline;
dojox.dtl.HtmlInline.prototype.declaredClass = "dojox.dtl.HtmlInline";