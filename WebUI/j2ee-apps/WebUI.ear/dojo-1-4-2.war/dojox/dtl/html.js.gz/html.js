dojo.provide("dojox.dtl.html");
dojo.deprecated("dojox.dtl.html", "All packages and classes in dojox.dtl that start with Html or html have been renamed to Dom or dom");
dojo.require("dojox.dtl.dom");
dojox.dtl.HtmlTemplate = dojox.dtl.DomTemplate;