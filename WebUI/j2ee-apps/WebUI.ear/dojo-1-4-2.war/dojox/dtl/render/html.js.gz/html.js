dojo.provide("dojox.dtl.render.html");
dojo.require("dojox.dtl.render.dom");
dojox.dtl.render.html.Render = dojox.dtl.render.dom.Render;