({
	"nodeActions": "${nodeName} Actions",
	"selectContents": "Select contents",
	"selectElement": "Select element",
	"deleteElement": "Delete element",
	"deleteContents": "Delete contents",
	"moveStart": "Move cursor to start",
	"moveEnd": "Move cursor to end"
})
