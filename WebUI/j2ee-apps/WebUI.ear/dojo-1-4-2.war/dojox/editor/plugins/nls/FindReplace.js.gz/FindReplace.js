({
	"findLabel": "Find what:",
	"replaceLabel": "Replace with:",
	"findReplace": "Toggle Find/Replace",
	"matchCase": "Match Case", 
	"backwards": "Backwards",
	"replaceAll": "All Occurances", 
	"findButton": "Find",
	"replaceButton": "Replace",
	"replaceDialogText": "Replaced ${0} occurances."
})
