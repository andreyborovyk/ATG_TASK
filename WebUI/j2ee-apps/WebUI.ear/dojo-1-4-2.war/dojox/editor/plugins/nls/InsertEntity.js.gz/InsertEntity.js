({
	insertEntity: "Insert Symbol"
})