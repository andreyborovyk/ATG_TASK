({
	"save": "Save"
})