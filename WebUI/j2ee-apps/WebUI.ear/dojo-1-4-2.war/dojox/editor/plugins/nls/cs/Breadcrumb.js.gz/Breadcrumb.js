({
	"nodeActions": "Akce uzlu ${nodeName}",
	"selectContents": "Vybrat obsah",
	"selectElement": "Vybrat prvek",
	"deleteElement": "Odstranit prvek",
	"deleteContents": "Odstranit obsah",
	"moveStart": "Přesunout ukazatel na začátek",
	"moveEnd": "Přesunout ukazatel na konec"
})

