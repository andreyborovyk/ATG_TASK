({
	"findLabel": "Hledaný řetězec:",
	"replaceLabel": "Nahrazující řetězec:",
	"findReplace": "Přepnout hledání/nahrazování",
	"matchCase": "S rozlišením velkých a malých písmen", 
	"backwards": "V opačném směru",
	"replaceAll": "Všechny výskyty", 
	"findButton": "Najít",
	"replaceButton": "Nahradit",
	"replaceDialogText": "Počet nahrazených výskytů: ${0}. "
})

