({
	insertEntity: "Vložit symbol"
})

