({
	"preview": "Náhled"
})

