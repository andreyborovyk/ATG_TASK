({
	smiley: "Vložit emotikonu",
	emoticonSmile: "úsměv",
	emoticonLaughing: "smích",
	emoticonWink: "mrknutí",
	emoticonGrin: "úšklebek",
	emoticonCool: "skvělé",
	emoticonAngry: "hněv",  
	emoticonHalf: "polovina", 
	emoticonEyebrow: "obočí",
	emoticonFrown: "zamračení",
	emoticonShy: "stud",
	emoticonGoofy: "potrhlost",
	emoticonOops: "ouha",
	emoticonTongue: "jazyk",
	emoticonIdea: "nápad",
	emoticonYes: "ano",
	emoticonNo: "ne",	
	emoticonAngel: "anděl",
	emoticonCrying: "pláč"
})

