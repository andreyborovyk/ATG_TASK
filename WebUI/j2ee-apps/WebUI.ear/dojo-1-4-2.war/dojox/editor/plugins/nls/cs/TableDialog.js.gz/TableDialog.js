({
	insertTableTitle: "Vložit tabulku",
	modifyTableTitle: "Upravit tabulku",
	rows: "Řádky:",
	columns: "Sloupce:",
	align: "Zarovnat:",
	cellPadding: "Okraj buňky:",
	cellSpacing: "Odstup buněk:",
	tableWidth: "Šířka tabulky:",
	backgroundColor: "Barva pozadí:",
	borderColor: "Barva ohraničení:",
	borderThickness: "TloušťkaOhraničení",
	pixels: "Pixely",
	percent: "procent",
	pixels: "pixelů",
	"default": "výchozí",
	left: "vlevo",
	center: "střed",
	right: "vpravo",
	buttonSet: "Nastavit", // translated elsewhere?
	buttonInsert: "Vložit",

	selectTableLabel: "Vybrat tabulku",
	insertTableRowBeforeLabel: "Přidat řádek před",
	insertTableRowAfterLabel: "Přidat řádek za",
	insertTableColumnBeforeLabel: "Přidat sloupec před",
	insertTableColumnAfterLabel: "Přidat sloupec za",
	deleteTableRowLabel: "Odstranit řádek",
	deleteTableColumnLabel: "Odstranit sloupec"
})

