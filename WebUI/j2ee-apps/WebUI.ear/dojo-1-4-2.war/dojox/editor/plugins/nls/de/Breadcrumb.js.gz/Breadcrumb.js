({
	"nodeActions": "Aktionen für ${nodeName}",
	"selectContents": "Inhalt auswählen",
	"selectElement": "Element auswählen",
	"deleteElement": "Element löschen",
	"deleteContents": "Inhalt löschen",
	"moveStart": "Cursor an Anfang verschieben",
	"moveEnd": "Cursor an Ende verschieben"
})

