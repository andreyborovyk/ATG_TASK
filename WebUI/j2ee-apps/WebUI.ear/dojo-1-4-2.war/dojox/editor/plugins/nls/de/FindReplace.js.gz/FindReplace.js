({
	"findLabel": "Suchbegriff:",
	"replaceLabel": "Ersetzen durch:",
	"findReplace": "Suchen/Ersetzen",
	"matchCase": "Groß- und Kleinschreibung abgleichen", 
	"backwards": "Zurück",
	"replaceAll": "Alle Vorkommen", 
	"findButton": "Suchen",
	"replaceButton": "Ersetzen",
	"replaceDialogText": "Es wurden ${0} Vorkommen ersetzt."
})

