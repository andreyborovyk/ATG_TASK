({
	insertEntity: "Symbol einfügen"
})

