({
	"pageBreak": "Seitenumbruch"
})

