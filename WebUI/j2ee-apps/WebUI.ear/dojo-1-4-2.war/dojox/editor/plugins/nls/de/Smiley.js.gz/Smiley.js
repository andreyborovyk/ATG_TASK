({
	smiley: "Emoticon einfügen",
	emoticonSmile: "Lächeln",
	emoticonLaughing: "Lachen",
	emoticonWink: "Augenzwinkern",
	emoticonGrin: "Grinsen",
	emoticonCool: "Cool",
	emoticonAngry: "Zornig",  
	emoticonHalf: "Halb", 
	emoticonEyebrow: "Hochgezogene Augenbraue",
	emoticonFrown: "Stirnrunzeln",
	emoticonShy: "Schüchtern",
	emoticonGoofy: "Albern",
	emoticonOops: "Hoppla",
	emoticonTongue: "Zunge",
	emoticonIdea: "Idee",
	emoticonYes: "Ja",
	emoticonNo: "Nein",	
	emoticonAngel: "Engel",
	emoticonCrying: "Weinen"
})

