({
	"nodeActions": "Acciones de ${nodeName}",
	"selectContents": "Seleccionar contenido",
	"selectElement": "Seleccionar elemento",
	"deleteElement": "Suprimir elemento",
	"deleteContents": "Suprimir contenido",
	"moveStart": "Mover cursor al inicio",
	"moveEnd": "Mover cursor al final"
})

