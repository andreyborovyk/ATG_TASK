({
	"findLabel": "Buscar:",
	"replaceLabel": "Sustituir por:",
	"findReplace": "Conmutar Buscar/Sustituir",
	"matchCase": "Coincidir mayúsculas y minúsculas", 
	"backwards": "Hacia atrás",
	"replaceAll": "Todas las apariciones", 
	"findButton": "Buscar",
	"replaceButton": "Sustituir",
	"replaceDialogText": "Se han sustituido ${0} apariciones."
})

