({
	insertEntity: "Insertar símbolo"
})

