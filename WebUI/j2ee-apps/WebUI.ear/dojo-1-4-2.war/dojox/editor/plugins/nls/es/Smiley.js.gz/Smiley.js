({
	smiley: "Insertar emoticono",
	emoticonSmile: "sonrisa",
	emoticonLaughing: "risa",
	emoticonWink: "guiño",
	emoticonGrin: "carcajada",
	emoticonCool: "guay",
	emoticonAngry: "enfadado",  
	emoticonHalf: "escéptico", 
	emoticonEyebrow: "ceja levantada",
	emoticonFrown: "ceño fruncido",
	emoticonShy: "tímido",
	emoticonGoofy: "patoso",
	emoticonOops: "lo siento",
	emoticonTongue: "burlón",
	emoticonIdea: "idea",
	emoticonYes: "sí",
	emoticonNo: "no",	
	emoticonAngel: "ángel",
	emoticonCrying: "llorando"
})

