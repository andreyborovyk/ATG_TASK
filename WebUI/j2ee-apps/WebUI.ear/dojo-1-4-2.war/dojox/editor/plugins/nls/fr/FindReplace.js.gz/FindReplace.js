({
	"findLabel": "Que rechercher :",
	"replaceLabel": "Remplacer par :",
	"findReplace": "Rechercher/Remplacer",
	"matchCase": "Respecter la casse", 
	"backwards": "Vers l'arrière",
	"replaceAll": "Toutes les occurrences", 
	"findButton": "Rechercher",
	"replaceButton": "Remplacer",
	"replaceDialogText": "${0} occurrence(s) remplacée(s)."
})

