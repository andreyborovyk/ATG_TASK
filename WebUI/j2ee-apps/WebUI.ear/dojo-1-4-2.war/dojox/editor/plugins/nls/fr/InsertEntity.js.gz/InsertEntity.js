({
	insertEntity: "Insertion d'un symbole"
})

