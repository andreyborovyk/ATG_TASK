({
	"save": "Sauvegarder"
})

