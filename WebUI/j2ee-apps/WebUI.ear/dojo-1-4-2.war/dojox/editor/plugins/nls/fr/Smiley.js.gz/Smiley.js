({
	smiley: "Insérer une émoticône",
	emoticonSmile: "sourire",
	emoticonLaughing: "rire",
	emoticonWink: "clin d'oeil",
	emoticonGrin: "sourire large",
	emoticonCool: "calme",
	emoticonAngry: "colère",  
	emoticonHalf: "demi", 
	emoticonEyebrow: "sourcils",
	emoticonFrown: "froncement de sourcils",
	emoticonShy: "timide",
	emoticonGoofy: "dingo",
	emoticonOops: "oops",
	emoticonTongue: "langue",
	emoticonIdea: "idée",
	emoticonYes: "oui",
	emoticonNo: "non",	
	emoticonAngel: "ange",
	emoticonCrying: "pleurs"
})

