({
	"findLabel": "Keresés: ",
	"replaceLabel": "Csere: ",
	"findReplace": "Keresés/Csere váltása",
	"matchCase": "Kis- és nagybetűk egyeztetése", 
	"backwards": "Visszafelé",
	"replaceAll": "Minden előfordulás", 
	"findButton": "Keresés",
	"replaceButton": "Csere",
	"replaceDialogText": "${0} előfordulás cseréje megtörtént. "
})

