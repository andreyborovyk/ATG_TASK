({
	insertEntity: "Szimbólum beszúrása"
})

