({
	"showBlockNodes": "HTML blokk elemek megjelenítése"
})

