({
	"nodeActions": "Azioni ${nodeName}",
	"selectContents": "Seleziona contenuto",
	"selectElement": "Seleziona elemento",
	"deleteElement": "Elimina elemento",
	"deleteContents": "Elimina contenuto",
	"moveStart": "Sposta il cursore per iniziare",
	"moveEnd": "Sposta il cursore per terminare"
})

