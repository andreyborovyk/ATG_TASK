({
	"findLabel": "Trova:",
	"replaceLabel": "Sostituisci con:",
	"findReplace": "Mostra/Nascondi Trova/Sostituisci",
	"matchCase": "Maiuscole/minuscole", 
	"backwards": "Indietro",
	"replaceAll": "Tutte le occorrenze", 
	"findButton": "Trova",
	"replaceButton": "Sostituisci",
	"replaceDialogText": "Occorrenze sostituite: ${0}."
})

