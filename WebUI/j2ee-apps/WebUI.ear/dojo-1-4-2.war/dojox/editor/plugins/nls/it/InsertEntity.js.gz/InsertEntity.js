({
	insertEntity: "Inserisci simbolo"
})

