({
	"pageBreak": "Interruzione di pagina"
})

