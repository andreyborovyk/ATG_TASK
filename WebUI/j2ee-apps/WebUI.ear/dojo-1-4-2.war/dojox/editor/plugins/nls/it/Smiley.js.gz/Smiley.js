({
	smiley: "Inserisci emoticon",
	emoticonSmile: "sorriso",
	emoticonLaughing: "risata",
	emoticonWink: "occhiolino",
	emoticonGrin: "ghigno",
	emoticonCool: "figo",
	emoticonAngry: "arrabbiato",  
	emoticonHalf: "metà", 
	emoticonEyebrow: "sopracciglia",
	emoticonFrown: "triste",
	emoticonShy: "timido",
	emoticonGoofy: "sciocco",
	emoticonOops: "ops",
	emoticonTongue: "linguaccia",
	emoticonIdea: "idea",
	emoticonYes: "yes",
	emoticonNo: "no",	
	emoticonAngel: "angelo",
	emoticonCrying: "in lacrime"
})

