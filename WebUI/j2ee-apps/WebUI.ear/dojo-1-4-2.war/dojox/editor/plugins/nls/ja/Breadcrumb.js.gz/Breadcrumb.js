({
	"nodeActions": "${nodeName} アクション",
	"selectContents": "内容の選択",
	"selectElement": "要素の選択",
	"deleteElement": "要素の削除",
	"deleteContents": "内容の削除",
	"moveStart": "開始するためにカーソルを移動",
	"moveEnd": "終了するためにカーソルを移動"
})

