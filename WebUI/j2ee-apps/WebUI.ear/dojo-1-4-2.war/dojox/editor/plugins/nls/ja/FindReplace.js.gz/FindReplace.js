({
	"findLabel": "検索内容:",
	"replaceLabel": "次で置換:",
	"findReplace": "検索/置換の切り替え",
	"matchCase": "大/小文字を区別", 
	"backwards": "後方",
	"replaceAll": "すべてのオカレンス", 
	"findButton": "検索",
	"replaceButton": "置換",
	"replaceDialogText": "${0} 個のオカレンスを置換しました。"
})

