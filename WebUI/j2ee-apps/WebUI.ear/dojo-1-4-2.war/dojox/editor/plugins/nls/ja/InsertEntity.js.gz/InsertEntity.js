({
	insertEntity: "記号の挿入"
})

