({
	smiley: "顔文字の挿入",
	emoticonSmile: "微笑",
	emoticonLaughing: "笑い",
	emoticonWink: "ウィンク",
	emoticonGrin: "笑顔",
	emoticonCool: "無愛想",
	emoticonAngry: "怒り",  
	emoticonHalf: "半分", 
	emoticonEyebrow: "眉毛",
	emoticonFrown: "眉をひそめる",
	emoticonShy: "はにかんだ",
	emoticonGoofy: "おろかな",
	emoticonOops: "おっと",
	emoticonTongue: "舌を出す",
	emoticonIdea: "アイデア",
	emoticonYes: "はい",
	emoticonNo: "いいえ",	
	emoticonAngel: "エンジェル",
	emoticonCrying: "泣く"
})

