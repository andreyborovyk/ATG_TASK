({
	insertTableTitle: "テーブルの挿入",
	modifyTableTitle: "テーブルの変更",
	rows: "行",
	columns: "列",
	align: "位置合わせ",
	cellPadding: "セル余白:",
	cellSpacing: "セル間隔:",
	tableWidth: "テーブルの幅:",
	backgroundColor: "背景色:",
	borderColor: "ボーダー色:",
	borderThickness: "ボーダー線幅",
	pixels: "ピクセル",
	percent: "パーセント",
	pixels: "ピクセル",
	"default": "default",
	left: "左",
	center: "中央",
	right: "右",
	buttonSet: "設定", // translated elsewhere?
	buttonInsert: "挿入",

	selectTableLabel: "テーブルの選択",
	insertTableRowBeforeLabel: "行を前に追加",
	insertTableRowAfterLabel: "行を後に追加",
	insertTableColumnBeforeLabel: "列を前に追加",
	insertTableColumnAfterLabel: "列を後に追加",
	deleteTableRowLabel: "行の削除",
	deleteTableColumnLabel: "列の削除"
})

