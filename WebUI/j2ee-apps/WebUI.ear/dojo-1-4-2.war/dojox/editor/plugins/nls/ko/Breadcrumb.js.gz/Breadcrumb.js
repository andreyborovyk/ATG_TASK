({
	"nodeActions": "${nodeName} 조치",
	"selectContents": "컨텐츠 선택",
	"selectElement": "요소 선택",
	"deleteElement": "요소 삭제",
	"deleteContents": "컨텐츠 삭제",
	"moveStart": "커서를 이동하여 시작",
	"moveEnd": "커서를 이동하여 종료"
})

