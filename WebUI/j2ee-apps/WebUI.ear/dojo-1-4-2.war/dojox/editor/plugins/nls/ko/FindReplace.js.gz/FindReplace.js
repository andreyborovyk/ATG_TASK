({
	"findLabel": "찾을 문자열:",
	"replaceLabel": "바꿀 대상:",
	"findReplace": "토글 찾기/바꾸기",
	"matchCase": "대소문자 일치", 
	"backwards": "뒤로",
	"replaceAll": "모두 바꾸기", 
	"findButton": "찾기",
	"replaceButton": "바꾸기",
	"replaceDialogText": "${0}개를 바꿨습니다."
})

