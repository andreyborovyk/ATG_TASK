({
	"findLabel": "Znajdź:",
	"replaceLabel": "Zastąp przez:",
	"findReplace": "Przełącz znajdowanie/zastępowanie",
	"matchCase": "Uwzględniaj wielkość liter", 
	"backwards": "Do tyłu",
	"replaceAll": "Wszystkie wystąpienia", 
	"findButton": "Znajdź",
	"replaceButton": "Zastąp",
	"replaceDialogText": "Zastąpione wystąpienia: ${0}."
})

