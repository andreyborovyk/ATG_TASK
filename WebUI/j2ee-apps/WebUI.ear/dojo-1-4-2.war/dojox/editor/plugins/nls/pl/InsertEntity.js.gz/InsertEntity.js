({
	insertEntity: "Wstaw symbol"
})

