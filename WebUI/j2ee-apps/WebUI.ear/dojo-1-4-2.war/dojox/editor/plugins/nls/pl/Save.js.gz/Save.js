({
	"save": "Zapisz"
})

