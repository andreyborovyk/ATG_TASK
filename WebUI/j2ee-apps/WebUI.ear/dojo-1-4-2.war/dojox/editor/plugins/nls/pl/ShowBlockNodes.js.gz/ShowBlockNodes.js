({
	"showBlockNodes": "Pokaż elementy bloków HTML"
})

