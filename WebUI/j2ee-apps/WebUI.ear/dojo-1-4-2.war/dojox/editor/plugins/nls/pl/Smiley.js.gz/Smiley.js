({
	smiley: "Wstaw emotikon",
	emoticonSmile: "uśmiech",
	emoticonLaughing: "śmiech",
	emoticonWink: "mrugnięcie",
	emoticonGrin: "szeroki uśmiech",
	emoticonCool: "na luzie",
	emoticonAngry: "złość",  
	emoticonHalf: "niesmak", 
	emoticonEyebrow: "brew",
	emoticonFrown: "niezadowolenie",
	emoticonShy: "nieśmiałość",
	emoticonGoofy: "niezdarność",
	emoticonOops: "oj",
	emoticonTongue: "język",
	emoticonIdea: "pomysł",
	emoticonYes: "Tak",
	emoticonNo: "Nie",	
	emoticonAngel: "anioł",
	emoticonCrying: "płacz"
})

