({
	"findLabel": "Localizar:",
	"replaceLabel": "Substituir por:",
	"findReplace": "Comutar Localizar/Substituir",
	"matchCase": "Caso de Correspondência", 
	"backwards": "Retroceder",
	"replaceAll": "Todas as Ocorrências", 
	"findButton": "Localizar",
	"replaceButton": "Substituir",
	"replaceDialogText": "${0} ocorrências substituídas."
})

