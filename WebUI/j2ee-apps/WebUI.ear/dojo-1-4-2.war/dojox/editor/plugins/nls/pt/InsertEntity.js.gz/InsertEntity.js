({
	insertEntity: "Inserir Símbolo"
})

