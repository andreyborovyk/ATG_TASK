({
	smiley: "Inserir Emoticon",
	emoticonSmile: "sorriso",
	emoticonLaughing: "gargalhando",
	emoticonWink: "piscando",
	emoticonGrin: "sorriso largo",
	emoticonCool: "legal",
	emoticonAngry: "bravo",  
	emoticonHalf: "confuso", 
	emoticonEyebrow: "sarcástico",
	emoticonFrown: "sobrancelhas franzidas",
	emoticonShy: "envergonhado",
	emoticonGoofy: "tonto",
	emoticonOops: "surpreso",
	emoticonTongue: "mostrando a língua",
	emoticonIdea: "ideia",
	emoticonYes: "sim",
	emoticonNo: "não",	
	emoticonAngel: "angelical",
	emoticonCrying: "chorando"
})

