({
	"findLabel": "Найти:",
	"replaceLabel": "Заменить на:",
	"findReplace": "Переключатель Поиск/Замена",
	"matchCase": "С учетом регистра", 
	"backwards": "Назад",
	"replaceAll": "Все вхождения", 
	"findButton": "Найти",
	"replaceButton": "Заменить",
	"replaceDialogText": "Заменено ${0} вхождений."
})

