({
	insertEntity: "Вставить символ"
})

