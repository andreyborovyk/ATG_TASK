({
	smiley: "Вставить значок настроения",
	emoticonSmile: "улыбка",
	emoticonLaughing: "смех",
	emoticonWink: "подмигивание",
	emoticonGrin: "усмешка",
	emoticonCool: "здорово",
	emoticonAngry: "злость",  
	emoticonHalf: "половина", 
	emoticonEyebrow: "удивление",
	emoticonFrown: "хмурый вид",
	emoticonShy: "застенчивость",
	emoticonGoofy: "глупый",
	emoticonOops: "уупс",
	emoticonTongue: "насмешка",
	emoticonIdea: "есть идея",
	emoticonYes: "да",
	emoticonNo: "нет",	
	emoticonAngel: "ангел",
	emoticonCrying: "плачь"
})

