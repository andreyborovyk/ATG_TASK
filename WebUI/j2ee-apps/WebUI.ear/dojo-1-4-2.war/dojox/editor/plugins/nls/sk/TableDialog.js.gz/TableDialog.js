({
	insertTableTitle: "Vložiť tabuľku",
	modifyTableTitle: "Upraviť tabuľku",
	rows: "Riadky:",
	columns: "Stĺpce:",
	align: "Zarovnať:",
	cellPadding: "Odsadenie obsahu buniek:",
	cellSpacing: "Rozstupy buniek:",
	tableWidth: "Šírka tabuľky:",
	backgroundColor: "Farba pozadia:",
	borderColor: "Farba rámčeka:",
	borderThickness: "Hrúbka rámčeka",
	pixels: "Pixely",
	percent: "percentá",
	pixels: "pixely",
	"default": "štandardne",
	left: "vľavo",
	center: "na stred",
	right: "vpravo",
	buttonSet: "Nastaviť", // translated elsewhere?
	buttonInsert: "Vložiť",

	selectTableLabel: "Vybrať tabuľku",
	insertTableRowBeforeLabel: "Pridať riadok pred",
	insertTableRowAfterLabel: "Pridať riadok za",
	insertTableColumnBeforeLabel: "Pridať stĺpec pred",
	insertTableColumnAfterLabel: "Pridať stĺpec za",
	deleteTableRowLabel: "Vymazať riadok",
	deleteTableColumnLabel: "Vymazať stĺpec"
})

