({
	insertTableTitle: "แทรกตาราง",
	modifyTableTitle: "ปรับเปลี่ยนตาราง",
	rows: "แถว:",
	columns: "คอลัมน์:",
	align: "จัดตำแหน่ง:",
	cellPadding: "ส่วนเสริมเซลล์:",
	cellSpacing: "ระยะห่างเซลล์:",
	tableWidth: "ความกว้างของตาราง:",
	backgroundColor: "สีพื้นหลัง:",
	borderColor: "สีเส้นขอบ:",
	borderThickness: "ความหนาเส้นขอบ",
	pixels: "พิกเซล",
	percent: "เปอร์เซ็นต์",
	pixels: "พิกเซล",
	"default": "ดีฟอลต์",
	left: "ซ้าย",
	center: "กึ่งกลาง",
	right: "ขวา",
	buttonSet: "ตั้งค่า", // translated elsewhere?
	buttonInsert: "แทรก",

	selectTableLabel: "เลือกตาราง",
	insertTableRowBeforeLabel: "เพิ่มแถวก่อน",
	insertTableRowAfterLabel: "เพิ่มแถวหลัง",
	insertTableColumnBeforeLabel: "เพิ่มคอลัมน์ก่อน",
	insertTableColumnAfterLabel: "เพิ่มคอลัมน์หลัง",
	deleteTableRowLabel: "ลบแถว",
	deleteTableColumnLabel: "ลบคอลัมน์"
})

