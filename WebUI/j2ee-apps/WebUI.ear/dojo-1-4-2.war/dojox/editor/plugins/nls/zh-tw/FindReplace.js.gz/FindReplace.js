({
	"findLabel": "尋找目標：",
	"replaceLabel": "取代為：",
	"findReplace": "切換尋找/取代",
	"matchCase": "大小寫相符", 
	"backwards": "向後",
	"replaceAll": "所有出現位置", 
	"findButton": "尋找",
	"replaceButton": "取代",
	"replaceDialogText": "取代了 ${0} 項。"
})

