({
	insertEntity: "插入符號"
})

