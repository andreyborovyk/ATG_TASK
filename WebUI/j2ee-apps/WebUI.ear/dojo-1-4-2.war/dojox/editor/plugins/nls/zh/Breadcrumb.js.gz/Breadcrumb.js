({
	"nodeActions": "${nodeName} 操作",
	"selectContents": "选择内容",
	"selectElement": "选择元素",
	"deleteElement": "删除元素",
	"deleteContents": "删除内容",
	"moveStart": "将光标移至开头",
	"moveEnd": "将光标移至结尾"
})

