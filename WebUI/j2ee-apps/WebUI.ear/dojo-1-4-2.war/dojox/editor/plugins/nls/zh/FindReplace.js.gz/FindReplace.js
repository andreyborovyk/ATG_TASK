({
	"findLabel": "查找对象：",
	"replaceLabel": "替换为：",
	"findReplace": "切换“查找/替换”",
	"matchCase": "大小写匹配", 
	"backwards": "向后",
	"replaceAll": "所有出现位置", 
	"findButton": "查找",
	"replaceButton": "替换",
	"replaceDialogText": "已替换 ${0} 个出现位置。"
})

