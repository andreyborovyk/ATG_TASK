({
	insertEntity: "插入符号"
})

