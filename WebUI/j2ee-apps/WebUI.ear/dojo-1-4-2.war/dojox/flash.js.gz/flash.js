dojo.provide("dojox.flash");
dojo.require("dojox.flash._base");
