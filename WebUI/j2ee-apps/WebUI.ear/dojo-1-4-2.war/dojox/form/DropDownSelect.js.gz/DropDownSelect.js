dojo.deprecated("dojox.form.DropDownSelect", "Use dijit.form.Select instead", "2.0");

dojo.provide("dojox.form.DropDownSelect");
dojo.require("dijit.form.Select");

dojo.setObject("dojox.form.DropDownSelect", dijit.form.Select);