dojo.provide("dojox.form.FileInputBlind");
// FIXME: break out code in 2.0. Leave this stub in place until then. Leave FileInputBlind code in Auto.js for
// backwards compatibility.
dojo.require("dojox.form.FileInputAuto");