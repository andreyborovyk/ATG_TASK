dojo.deprecated("dojox.form._FormSelectWidget", "Use dijit.form._FormSelectWidget instead", "2.0");

dojo.provide("dojox.form._FormSelectWidget");
dojo.require("dijit.form._FormSelectWidget");

dojo.setObject("dojox.form._FormSelectWidget", dijit.form._FormSelectWidget);