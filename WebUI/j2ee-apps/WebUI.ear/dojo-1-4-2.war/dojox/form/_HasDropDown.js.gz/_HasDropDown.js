dojo.deprecated("dojox.form._HasDropDown", "Use dijit._HasDropDown instead", "2.0");

dojo.provide("dojox.form._HasDropDown");
dojo.require("dijit._HasDropDown");

dojo.setObject("dojox.form._HasDropDown", dijit._HasDropDown);