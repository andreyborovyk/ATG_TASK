({
        nomatchMessage: "كلمة السرية غير مطابقة.",
		badPasswordMessage: "كلمة سرية غير صحيحة."
})

