({
        nomatchMessage: "Les contrasenyes no coincideixen",
		badPasswordMessage: "La contrasenya no és correcta"
})

