({
        nomatchMessage: "Hesla se neshodují.",
		badPasswordMessage: "Neplatné heslo."
})

