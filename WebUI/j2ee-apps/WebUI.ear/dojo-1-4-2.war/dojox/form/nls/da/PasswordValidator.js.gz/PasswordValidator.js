({
        nomatchMessage: "Adgangskoderne stemmer ikke overens.",
		badPasswordMessage: "Ugyldig adgangskode."
})

