({
        nomatchMessage: "Die Kennwörter stimmen nicht überein.",
		badPasswordMessage: "Ungültiges Kennwort."
})

