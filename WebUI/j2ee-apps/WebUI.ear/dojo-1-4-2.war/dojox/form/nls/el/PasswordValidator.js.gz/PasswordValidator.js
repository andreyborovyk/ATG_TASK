({
        nomatchMessage: "Οι κωδικοί πρόσβασης δεν συμφωνούν.",
		badPasswordMessage: "Μη έγκυρος κωδικός πρόσβασης."
})

