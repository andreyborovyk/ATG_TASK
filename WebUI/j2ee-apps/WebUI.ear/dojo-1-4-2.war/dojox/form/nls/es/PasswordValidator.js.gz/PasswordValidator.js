({
        nomatchMessage: "Las contraseñas no coinciden.",
		badPasswordMessage: "Contraseña no válida."
})

