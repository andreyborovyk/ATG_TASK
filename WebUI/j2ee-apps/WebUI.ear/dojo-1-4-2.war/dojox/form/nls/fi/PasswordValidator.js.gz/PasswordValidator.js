({
        nomatchMessage: "Salasanat eivät täsmää.",
		badPasswordMessage: "Salasana ei kelpaa."
})

