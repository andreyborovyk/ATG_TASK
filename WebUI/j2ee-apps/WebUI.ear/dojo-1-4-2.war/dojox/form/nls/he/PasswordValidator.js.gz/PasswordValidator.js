({
        nomatchMessage: "הסיסמאות אינן זהות.",
		badPasswordMessage: "סיסמה לא חוקית."
})

