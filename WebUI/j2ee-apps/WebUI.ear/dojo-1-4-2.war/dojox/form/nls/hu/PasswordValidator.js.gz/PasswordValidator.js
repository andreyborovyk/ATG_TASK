({
        nomatchMessage: "A jelszavak nem egyeznek.",
		badPasswordMessage: "Érvénytelen jelszó."
})

