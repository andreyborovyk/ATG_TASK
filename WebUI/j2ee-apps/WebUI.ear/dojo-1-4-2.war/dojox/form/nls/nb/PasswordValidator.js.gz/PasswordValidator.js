({
        nomatchMessage: "Passordene samsvarer ikke.",
		badPasswordMessage: "Ugyldig passord."
})

