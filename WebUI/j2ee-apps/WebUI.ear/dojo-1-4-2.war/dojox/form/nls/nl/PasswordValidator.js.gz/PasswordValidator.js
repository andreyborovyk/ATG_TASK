({
        nomatchMessage: "Wachtwoorden komen niet overeen.",
		badPasswordMessage: "Ongeldig wachtwoord. "
})

