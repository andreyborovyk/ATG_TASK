({
        nomatchMessage: "Hasła nie są zgodne.",
		badPasswordMessage: "Niepoprawne hasło."
})

