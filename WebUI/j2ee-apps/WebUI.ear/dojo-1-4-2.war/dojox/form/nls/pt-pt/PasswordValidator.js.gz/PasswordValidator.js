({
        nomatchMessage: "As palavras-passe não correspondem.",
		badPasswordMessage: "Palavra-passe não válida."
})

