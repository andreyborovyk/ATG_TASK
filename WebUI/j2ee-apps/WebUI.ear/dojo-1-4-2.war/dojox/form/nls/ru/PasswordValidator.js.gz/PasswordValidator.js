({
        nomatchMessage: "Пароли не совпадают.",
		badPasswordMessage: "Неправильный пароль."
})

