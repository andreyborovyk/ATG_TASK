({
        nomatchMessage: "Heslá sa nezhodujú.",
		badPasswordMessage: "Neplatné heslo."
})

