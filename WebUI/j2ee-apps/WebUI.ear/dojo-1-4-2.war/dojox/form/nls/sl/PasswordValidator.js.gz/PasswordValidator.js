({
        nomatchMessage: "Gesli se ne ujemata.",
		badPasswordMessage: "Neveljavno geslo."
})

