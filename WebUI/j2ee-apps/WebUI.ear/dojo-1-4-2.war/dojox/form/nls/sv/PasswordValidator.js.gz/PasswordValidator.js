({
        nomatchMessage: "Lösenorden stämmer inte överens.",
		badPasswordMessage: "Ogiltigt lösenord."
})

