({
        nomatchMessage: "Parolalar eşleşmiyor.",
		badPasswordMessage: "Geçersiz Parola."
})

