({
        nomatchMessage: "密碼不符合。",
		badPasswordMessage: "無效的密碼。"
})

