dojo.provide("dojox.fx");

dojo.require("dojox.fx._base"); 
