dojo.provide("dojox.fx.easing");
dojo.deprecated("dojox.fx.easing","Upgraded to Core, use dojo.fx.easing instead","2.0");
dojo.require("dojo.fx.easing");
/*=====
	dojox.fx.easing = {
		// summary:
		//		An Alias to `dojo.fx.easing`. Moved to Core in Dojo 1.2.
	};
=====*/
dojox.fx.easing = dojo.fx.easing;
