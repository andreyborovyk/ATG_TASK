dojo.provide("dojox.grid._CheckBoxSelector");

dojo.require("dojox.grid._Selector");
