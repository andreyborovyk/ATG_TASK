({
	singleSort: "Single Sort",
	nestedSort: "Nested Sort",
	ascending: "Ascending",
	descending: "Descending",
	sortingState: "${0} - ${1}",
	unsorted: "Do not sort this column"
})
