({
	singleSort: "Jednoduché řazení",
	nestedSort: "Vnořené řazení",
	ascending: "Vzestupně",
	descending: "Sestupně",
	unsorted: "Tento sloupec neřadit"
})

