({
	singleSort: "Einfache Sortierung",
	nestedSort: "Verschachtelte Sortierung",
	ascending: "Aufsteigend",
	descending: "Absteigend",
	unsorted: "Spalte nicht sortieren"
})

