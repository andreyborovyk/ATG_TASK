({
	singleSort: "Orden único",
	nestedSort: "Orden anidado",
	ascending: "Ascendente",
	descending: "Descendente",
	unsorted: "No ordenar esta columna"
})

