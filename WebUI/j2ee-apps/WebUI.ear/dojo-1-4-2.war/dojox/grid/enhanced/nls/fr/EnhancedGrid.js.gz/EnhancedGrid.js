({
	singleSort: "Tri unique",
	nestedSort: "Tri imbriqué",
	ascending: "Croissant",
	descending: "Décroissant",
	unsorted: "Ne pas trier cette colonne"
})

