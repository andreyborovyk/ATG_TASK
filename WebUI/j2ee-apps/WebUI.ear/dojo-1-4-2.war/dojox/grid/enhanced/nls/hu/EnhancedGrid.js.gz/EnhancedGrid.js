({
	singleSort: "Egyszerű rendezés",
	nestedSort: "Beágyazott rendezés",
	ascending: "Növekvő",
	descending: "Csökkenő",
	unsorted: "Az oszlop nincs rendezve"
})

