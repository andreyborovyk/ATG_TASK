({
	singleSort: "Ordinamento singolo",
	nestedSort: "Ordinamento nidificato",
	ascending: "Crescente",
	descending: "Decrescente",
	unsorted: "Non ordinare questa colonna"
})

