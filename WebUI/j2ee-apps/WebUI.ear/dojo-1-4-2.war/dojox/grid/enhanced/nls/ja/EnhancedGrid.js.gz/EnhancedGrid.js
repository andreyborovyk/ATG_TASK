({
	singleSort: "単一ソート",
	nestedSort: "ネストされたソート",
	ascending: "昇順",
	descending: "降順",
	unsorted: "この列はソートしないでください"
})

