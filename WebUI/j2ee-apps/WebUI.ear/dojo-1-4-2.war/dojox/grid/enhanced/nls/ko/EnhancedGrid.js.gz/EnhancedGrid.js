({
	singleSort: "단일 정렬",
	nestedSort: "중첩 정렬",
	ascending: "오름차순",
	descending: "내림차순",
	unsorted: "이 열을 정렬하지 않음"
})

