({
	singleSort: "Sortowanie pojedyncze",
	nestedSort: "Sortowanie zagnieżdżone",
	ascending: "Rosnąco",
	descending: "Malejąco",
	unsorted: "Nie sortuj tej kolumny"
})

