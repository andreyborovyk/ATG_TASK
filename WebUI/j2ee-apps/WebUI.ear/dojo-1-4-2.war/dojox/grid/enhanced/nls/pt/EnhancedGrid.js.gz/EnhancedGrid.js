({
	singleSort: "Classificação Única",
	nestedSort: "Classificação Aninhada",
	ascending: "Ascendente",
	descending: "Descendente",
	unsorted: "Não classificar esta coluna"
})

