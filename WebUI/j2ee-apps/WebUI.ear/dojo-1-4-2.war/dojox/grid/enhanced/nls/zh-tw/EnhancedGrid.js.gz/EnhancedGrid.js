({
	singleSort: "單一排序",
	nestedSort: "巢狀排序",
	ascending: "遞增",
	descending: "遞減",
	unsorted: "不排序此直欄"
})

