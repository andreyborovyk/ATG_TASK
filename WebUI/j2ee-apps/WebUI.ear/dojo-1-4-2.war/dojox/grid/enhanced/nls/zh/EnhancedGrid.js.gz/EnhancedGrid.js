({
	singleSort: "单一排序",
	nestedSort: "嵌套排序",
	ascending: "升序",
	descending: "降序",
	unsorted: "不要对此列排序"
})

