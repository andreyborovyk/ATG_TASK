dojo.provide("dojox.highlight");
dojo.require("dojox.highlight._base"); 
