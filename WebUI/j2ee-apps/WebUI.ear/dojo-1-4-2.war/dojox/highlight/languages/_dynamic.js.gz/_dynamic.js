dojo.provide("dojox.highlight.languages._dynamic");

/* common scripted languages */
dojo.require("dojox.highlight.languages.python");
// dojo.require("dojox.highlight.languages.perl");
// dojo.require("dojox.highlight.languages.php");
// dojo.require("dojox.highlight.languages.ruby");
