dojo.provide("dojox.highlight.languages._static");

/* common static languages */
dojo.require("dojox.highlight.languages.cpp")
// dojo.require("dojox.highlight.languages.java");
dojo.require("dojox.highlight.languages.delphi");
