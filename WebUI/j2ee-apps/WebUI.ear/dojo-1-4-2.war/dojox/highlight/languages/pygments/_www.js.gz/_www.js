dojo.provide("dojox.highlight.languages.pygments._www");

/* common web-centric languages */
dojo.require("dojox.highlight.languages.pygments.xml");
dojo.require("dojox.highlight.languages.pygments.html");
dojo.require("dojox.highlight.languages.pygments.css");
//dojo.require("dojox.highlight.languages.pygments.django");
dojo.require("dojox.highlight.languages.pygments.javascript");