dojo.provide("dojox.image");
dojo.require("dojox.image._base");
