dojo.provide("dojox.jsonPath");
dojo.require("dojox.jsonPath.query");
