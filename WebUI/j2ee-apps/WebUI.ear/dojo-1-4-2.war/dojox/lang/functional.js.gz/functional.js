dojo.provide("dojox.lang.functional");

dojo.require("dojox.lang.functional.lambda");
dojo.require("dojox.lang.functional.array");
dojo.require("dojox.lang.functional.object");
