dojo.provide("dojox.sketch");
dojo.require("dojox.xml.DomParser");
dojo.require("dojox.sketch.UndoStack");
dojo.require("dojox.sketch.Figure");
dojo.require("dojox.sketch.Toolbar");