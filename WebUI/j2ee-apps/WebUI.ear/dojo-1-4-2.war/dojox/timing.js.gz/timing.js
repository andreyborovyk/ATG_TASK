dojo.provide("dojox.timing");
dojo.require("dojox.timing._base"); 
