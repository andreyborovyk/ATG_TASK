dojo.provide("dojox.uuid");
dojo.require("dojox.uuid._base");
