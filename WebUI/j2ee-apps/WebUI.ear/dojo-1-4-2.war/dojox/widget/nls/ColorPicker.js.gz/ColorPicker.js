({
redLabel: "r",
greenLabel: "g",
blueLabel: "b",
hueLabel: "h",
saturationLabel: "s",
valueLabel: "v", /* aka intensity or brightness */
degLabel: "°",
hexLabel: "hex"
})
