({
next: "تالي",
previous: "‏سابق‏",
done: "اتمام"
})
