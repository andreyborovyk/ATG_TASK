({
next: "Següent",
previous: "Anterior",
done: "Fet"
})

