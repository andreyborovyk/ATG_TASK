({
redLabel: "č",
greenLabel: "z",
blueLabel: "m",
hueLabel: "o",
saturationLabel: "n",
valueLabel: "j", /* aka intensity or brightness */
hexLabel: "hex"
})

