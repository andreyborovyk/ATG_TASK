({
name: "Název",
path: "Cesta",
size: "Velikost (v bajtech)"
})
