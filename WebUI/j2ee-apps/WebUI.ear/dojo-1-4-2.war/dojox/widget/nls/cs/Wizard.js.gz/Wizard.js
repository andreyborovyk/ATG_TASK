({
next: "Další",
previous: "Předchozí",
done: "Hotovo"
})
