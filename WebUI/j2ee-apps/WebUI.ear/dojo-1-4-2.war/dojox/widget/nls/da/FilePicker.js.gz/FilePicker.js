({
name: "Navn",
path: "Sti",
size: "Størrelse (i byte)"
})
