({
next: "Næste",
previous: "Forrige",
done: "Udført"
})
