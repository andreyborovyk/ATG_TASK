({
name: "Name",
path: "Pfad",
size: "Größe (in Byte)"
})
