({
name: "Nombre",
path: "Vía de acceso",
size: "Tamaño (en bytes)"
})
