({
next: "Siguiente",
previous: "Anterior",
done: "Terminado"
})
