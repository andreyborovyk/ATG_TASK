({
name: "Nimi",
path: "Polku",
size: "Koko (tavuina)"
})
