({
name: "Nom",
path: "Chemin",
size: "Taille (en octets)"
})
