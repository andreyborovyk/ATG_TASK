({
next: "Következő",
previous: "Előző",
done: "Kész"
})
