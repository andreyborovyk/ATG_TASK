({
redLabel: "r",
greenLabel: "v",
blueLabel: "b",
hueLabel: "t",
saturationLabel: "s",
valueLabel: "v", /* aka intensity or brightness */
hexLabel: "hex"
})

