({
next: "Successivo",
previous: "Precedente",
done: "Eseguito"
})
