({
name: "Naam",
path: "Pad",
size: "Grootte (in bytes)"
})
