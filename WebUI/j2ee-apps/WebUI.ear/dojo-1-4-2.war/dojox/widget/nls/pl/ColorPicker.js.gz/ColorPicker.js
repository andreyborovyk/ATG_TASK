({
redLabel: "c",
greenLabel: "z",
blueLabel: "n",
hueLabel: "barwa",
saturationLabel: "nas.",
valueLabel: "jas.", /* aka intensity or brightness */
hexLabel: "szesnastkowe"
})

