({
name: "Nazwa",
path: "Ścieżka",
size: "Wielkość (w bajtach)"
})
