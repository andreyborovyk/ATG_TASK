({
next: "Następna",
previous: "Poprzednia",
done: "Gotowe"
})
