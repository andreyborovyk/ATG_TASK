({
next: "Seguinte",
previous: "Anterior",
done: "Concluído"
})
