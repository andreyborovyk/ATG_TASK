({
name: "Nome",
path: "Caminho",
size: "Tamanho (em bytes)"
})
