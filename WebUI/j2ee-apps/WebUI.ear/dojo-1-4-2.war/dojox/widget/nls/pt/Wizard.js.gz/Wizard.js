({
next: "Próximo",
previous: "Anterior",
done: "Concluído"
})
