({
name: "Názov",
path: "Cesta",
size: "Veľkosť (v bajtoch)"
})

