({
next: "Ďalej",
previous: "Späť",
done: "Hotovo"
})

