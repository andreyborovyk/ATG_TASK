({
next: "Naprej",
previous: "Nazaj",
done: "Opravljeno"
})

