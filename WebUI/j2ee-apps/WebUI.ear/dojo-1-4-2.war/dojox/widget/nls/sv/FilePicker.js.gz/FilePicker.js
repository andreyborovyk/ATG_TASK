({
name: "Namn",
path: "Sökväg",
size: "Storlek (byte)"
})
