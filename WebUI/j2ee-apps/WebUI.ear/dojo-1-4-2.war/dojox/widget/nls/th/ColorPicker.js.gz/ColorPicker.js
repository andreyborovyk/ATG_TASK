({
redLabel: "อาร์",
greenLabel: "จี",
blueLabel: "บี",
hueLabel: "เอช",
saturationLabel: "เอส",
valueLabel: "วี",
hexLabel: "เลขฐานสิบหก"
})
