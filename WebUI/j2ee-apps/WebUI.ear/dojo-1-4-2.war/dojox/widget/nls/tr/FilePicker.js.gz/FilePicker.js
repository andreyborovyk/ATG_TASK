({
name: "Ad",
path: "Yol",
size: "Boyut (bayt cinsinden)"
})
