dojo.provide("dojox.wire");
dojo.require("dojox.wire._base");

