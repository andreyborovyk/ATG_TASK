if(!dojo._hasResource["dojox.flash"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.flash"] = true;
dojo.provide("dojox.flash");
dojo.require("dojox.flash._common");

}
