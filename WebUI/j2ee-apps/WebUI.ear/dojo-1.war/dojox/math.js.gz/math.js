if(!dojo._hasResource["dojox.math"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.math"] = true;
dojo.provide("dojox.math");
dojo.require("dojox.math._base");

}
