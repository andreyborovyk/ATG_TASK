if(!dojo._hasResource["dojox.validate"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.validate"] = true;
dojo.provide("dojox.validate");
dojo.require("dojox.validate._base"); 

}
