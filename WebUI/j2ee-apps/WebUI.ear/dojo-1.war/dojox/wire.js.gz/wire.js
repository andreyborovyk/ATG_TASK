if(!dojo._hasResource["dojox.wire"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.wire"] = true;
dojo.provide("dojox.wire");
dojo.require("dojox.wire._base");


}
